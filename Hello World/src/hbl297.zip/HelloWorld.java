
public class HelloWorld {
	public static void hello() {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
	}
}
